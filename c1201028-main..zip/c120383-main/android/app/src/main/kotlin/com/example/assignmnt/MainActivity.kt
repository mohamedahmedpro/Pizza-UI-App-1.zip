package com.example.assignmnt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
